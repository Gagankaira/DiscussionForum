 <?php 
 Echo "<html>";

Echo
"
}
<style>
body {
  background-image: url('mainimage.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</style>
<body>
<h1 style='text-align:center'>Contact us:</h1>
<h2 style='text-align:center'> K GAGAN KUMAR</h2> 
<h2 style='text-align:center'>gagankaira960@gmail.com</h2>
<h2 style='text-align:center'>991297162</h2> </td>
<h2 style='text-align:center'>Mehdipatnam<br>Hyderabad</h2>
</body>
";
//your php code here

 
?>
