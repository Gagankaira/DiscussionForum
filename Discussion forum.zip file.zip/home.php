<?php

session_start();
if(! isset($_SESSION['username'])){
	header('location:loginform.php');
}
?>
<html>
<head>
<title>  HOME PAGE</title>
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<style>

body {
  background-image: url('mainimage.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
div.container{
	align:center;

}

</style>
</head>
</body>
<div class="container">


<a class="float-right"  href="logout.php"><h1 style='color:red'>LOGOUT</a >


<h1> WELCOME ---<?php echo $_SESSION['username']; ?>-----</h1><br><br><br><br>

<a href="hyd.php">ENTER TO CHOOSE LOCATIONS IN HYDERABAD</a > <br><br>
<br>
<a  href="sec.php">ENTER TO CHOOSE LOCATIONS IN SECUNDERABAD</a > <br><br>
<br>
<a href="rr.php">ENTER TO CHOOSE LOCATIONS IN RANGAREDDY</a > <br><br>
<br>
<a  href="nzb.php">ENTER TO CHOOSE LOCATIONS IN NIZAMABAD</a > <br><br>
<br>
<a href="gandipet.php">ENTER TO CHOOSE LOCATIONS IN GANDIPET</a > <br><br>

</div>
</body>

</html>