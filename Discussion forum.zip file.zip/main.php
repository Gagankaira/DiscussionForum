


<!DOCTYPE html>
<html>
<head>
<title style='color:black'>WELCOME TO THE WORKERS EMPLOYEMENT</title>
<style>
a.fixed {

position: fixed;

right: 20;

top: 0;

width: 260px;

border: 3px solid #73AD21;

}

body {
  background-image: url('mainimage.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}

</style>

</head>
<body>

<h1 style=" text-align:center;color:black">WELCOME TO THE WORKERS EMPLOYEMENT!</h1>

<p style='text-align:center;'> <a class="fixed;float-right"  href="loginform.php"> ENTER TO GO FOR SIGNUP</a></p>
<p style='text-align:center'> <a class="fixed;float-right" href="contact.php">CONTACT US</a></p>

</body>
</html>