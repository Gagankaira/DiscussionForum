<?php

session_start();
if(! isset($_SESSION['username'])){
	header('location:login.php');
}
?>
<html>
<head>
<title>  HOME PAGE</title>
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

</body>
<div class="container">


<a class="float-right" href="logout.php">LOGOUT</a >


<h1> WELCOME <?php echo $_SESSION['username']; ?></h1>

<a class="float-centre" href="address.php">CLICK ME TO CHOOSE LOCATIONS</a >


</div>
</body>

</html>