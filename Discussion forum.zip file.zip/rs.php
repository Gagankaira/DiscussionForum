 <?php 
 Echo "<html>";

Echo
"

<h2 style='text-align:center'>REGISTERED SUCCESSFULLY!<br></h2>

";
//your php code here

 
?>
</body>
 <center><a style ='text-align:centre;color:green' href="loginform.php">CLICK HERE  TO LOGIN</a ></center>
</body>