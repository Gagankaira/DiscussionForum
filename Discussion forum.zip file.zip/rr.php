 <?php 
 Echo "<html>";

Echo
"<h1 style='text-align:center'>THANK YOU FOR SELECTING RANGAREDDY AREA</h1>";
//your php code here
Print
"<h3 style='text-align:center;color:green;'> <br>          DETAILS WILL SENT TO YOUR MAIL!                    </h3>";
 
?>