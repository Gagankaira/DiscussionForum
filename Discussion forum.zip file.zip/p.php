<?php
$target_path="upload/";
$target_path=$target_path.basename($_FILES['fileToUpload]['name']);
if(move_upload_file($_FILES($_FILES['file upload']['tmp_name'],$terget_path)){
echo "File uploaded succesfully!";
}
else{
"sorry,file not uploaded,please try again";
}
?>