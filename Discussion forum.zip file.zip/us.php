 <?php 
 Echo "<html>";

Echo
"

<h2 style='text-align:center;color:red'>USER NOT FOUND!!<br></h2>

";
//your php code here

 
?>
</body>
 <center><a style ='text-align:centre;color:green' href="registerform.php">CLICK HERE  TO REGISTER!</a ></center>
</body>